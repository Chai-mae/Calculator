#include "calculator.h"
#include <QKeyEvent>
#include <QApplication>


Calculator::Calculator(QWidget *parent)
    : QWidget(parent)
{
    createWidgets();
    placeWidget();
    makeConnexions();

    sumSoFar = 0;
    factorSoFar = 0;
    waitingfordigit = true;



}
Calculator::~Calculator()
{
    delete disp;
    delete layout;
    delete buttonsLayout;
    delete operation ;
    delete enter;
    delete reset;
    delete sign;
    delete button;

}
void Calculator::createWidgets()
{
    //Creating the layouts
    layout = new QVBoxLayout();
    layout->setSpacing(2);

    //grid layout
    buttonsLayout = new QGridLayout;


    //creating the buttons
    for(int i=0; i < 10; i++)
    {
        digits.push_back(new QPushButton(QString::number(i)));
        digits.back()->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        digits.back()->resize(sizeHint().width(), sizeHint().height());
    }
    //enter button
    enter = new QPushButton("Enter",this);
    enter->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    enter->resize(sizeHint().width(), sizeHint().height());

    //operatiosn buttons

    operations.push_back(new QPushButton("+"));
    operations.push_back(new QPushButton("-"));
    operations.push_back(new QPushButton("*"));
    operations.push_back(new QPushButton("/"));

    //reset button
    reset= new QPushButton("C",this);

    // changing the sign button
    sign = new QPushButton("+/-", this);


    //creating the lcd
    disp = new QLCDNumber(this);
    disp->setDigitCount(6);

}

void Calculator::placeWidget()
{

    layout->addWidget(disp);
    layout->addLayout(buttonsLayout);



    // Adding the reset button
    buttonsLayout->addWidget(reset,0,0,1,3);



    //adding the buttons
    for(int i=1; i <10; i++)
        buttonsLayout->addWidget(digits[i], (i+2)/3, (i+2)%3);


    //Adding the operations
    for(int i=0; i < 4; i++)
        buttonsLayout->addWidget(operations[ i], i, 4);



    //Adding the 0 button
    buttonsLayout->addWidget(digits[0], 4, 0);
    //Adding the enter button
    buttonsLayout->addWidget(enter, 4, 1, 1,3);

    //Adding the sign button
    buttonsLayout->addWidget(sign,4,4);


    setLayout(layout);
}

void Calculator::makeConnexions()
{

 for(int i=0; i <10; i++)
         connect(digits[i], &QPushButton::clicked,
                 this, &Calculator::newDigit);

 connect(enter, &QPushButton::clicked, this, &Calculator::enterbutton);

 connect(reset, &QPushButton::clicked, this, &Calculator::resetSlot);

 connect(operations[0], &QPushButton::clicked, this, &Calculator::addOp);
 connect(operations[1], &QPushButton::clicked, this, &Calculator::addOp);
 connect(operations[2], &QPushButton::clicked, this, &Calculator::multOp);
 connect(operations[3], &QPushButton::clicked, this, &Calculator::multOp);

 connect(sign, &QPushButton::clicked, this, &Calculator::changeSign);
}

void Calculator::keyPressEvent(QKeyEvent *e)
{
    //Exiting the application by a click on space
    if( e->key() == Qt::Key_Escape)
        qApp->exit(0);


    //You could add more keyboard interation here (like digit to button)
}

void Calculator::newDigit()
{
    button = dynamic_cast<QPushButton *>(sender());
    int digitValue = button->text().toInt();
    if (disp->intValue() == 0 && digitValue == 0)
        return;

    if (waitingfordigit) {
        disp->display("0");
    waitingfordigit= false;
    }

    disp->display(disp->intValue()*10 + digitValue);
}
void Calculator::addOp(){

    auto button = dynamic_cast<QPushButton*>(sender());
    operation = new QString{button->text()};
    auto operand = disp->intValue();
    if(!pendingMultOp.isEmpty()){
        if(!calculate(operand, pendingMultOp)){
            Calculator::resetSlot();
            disp->display("Error");
            return;
        }
       disp->display(factorSoFar);
       operand= factorSoFar;
       factorSoFar= 0;
       pendingMultOp.clear();


    }
    if(!pendingAddOp.isEmpty()){
        if(!calculate(operand, pendingAddOp)){
            Calculator::resetSlot();
            disp->display("Error");
            return;
        }
        disp->display(sumSoFar);
        }
    else {
        sumSoFar = operand;
    }
    pendingAddOp = *operation;
    waitingfordigit = true;
}
void Calculator::multOp(){
    auto button = dynamic_cast<QPushButton*>(sender());
    operation = new QString{button->text()};
    auto operand = disp->intValue();
    if(!pendingMultOp.isEmpty()){
        if(!calculate(operand, pendingMultOp)){
            Calculator::resetSlot();
            disp->display("Error");
            return;
        }
       disp->display(factorSoFar);
      }
    else {
        factorSoFar = operand;
    }
    pendingMultOp = *operation;
    waitingfordigit = true;
}
void Calculator::enterbutton(){


auto operand = disp->intValue();
if(!pendingMultOp.isEmpty()){
    if(!calculate(operand, pendingMultOp)){
        Calculator::resetSlot();
        disp->display("Error");
        return;
    }
    operand = factorSoFar;
    factorSoFar=0;
    pendingMultOp.clear();
}
if(!pendingAddOp.isEmpty()){
    if(!calculate(operand, pendingAddOp)){
        Calculator::resetSlot();
        disp->display("Error");
        return;
    }
    pendingAddOp.clear();
}
else{
    sumSoFar= operand;
}
disp->display(sumSoFar);
sumSoFar = 0;
waitingfordigit = true;
}
void Calculator::resetSlot(){
    sumSoFar = 0;
    factorSoFar = 0;
    waitingfordigit = true;
    operation = nullptr;
    disp->display("0");


}
void Calculator::changeSign(){
    auto value = disp->intValue();
    if (value > 0){
        value = -value;
    }
    else if (value < 0){
        value= value * -1;
 } disp->display(value);
}
bool Calculator:: calculate(int rightOp, const QString &pendingOp){
    if (pendingOp == tr("+")) {
          sumSoFar += rightOp;
      } else if (pendingOp == tr("-")) {
          sumSoFar -= rightOp;
      } else if (pendingOp == tr("*")) {
          factorSoFar *= rightOp;
      } else if (pendingOp == tr("/")) {
      if (rightOp == 0)
          return false;
      else
           factorSoFar /= rightOp;

      }
      return true;

}

#include "clock.h"
#include<QHBoxLayout>
#include<QTime>

Clock::Clock(QWidget *parent) : QWidget(parent)
{
    creatwidgets();
    placewidgets();
    setWindowTitle("Digital Clock");
    updatetime();
    startTimer(1000);


}
void Clock::creatwidgets(){
   lcd1 = new QLCDNumber;
   lcd1->setDigitCount(2);
   lcd2 = new QLCDNumber;
   lcd2->setDigitCount(2);
   lcd3 = new QLCDNumber;
   lcd2->setDigitCount(2);

}
void Clock::placewidgets(){
    QLayout *layout = new QHBoxLayout;
    layout->addWidget(lcd1);
    layout->addWidget(lcd2);
    layout->addWidget(lcd3);
    setLayout(layout);
}
void Clock::updatetime(){
    auto T= QTime::currentTime();
     lcd1->display(T.hour());
     lcd2->display(T.minute());
     lcd3->display(T.second());
}
void Clock::timerEvent(QTimerEvent *e){
   updatetime();

}

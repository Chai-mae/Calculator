#ifndef CLOCK_H
#define CLOCK_H

#include <QWidget>
#include<QLCDNumber>
#include<QTimerEvent>

class Clock : public QWidget
{
    Q_OBJECT
public:
    explicit Clock(QWidget *parent = nullptr);
    void timerEvent(QTimerEvent *e);

protected:
    QLCDNumber *lcd1;
    QLCDNumber *lcd2;
    QLCDNumber *lcd3;
protected:
    void creatwidgets();
    void placewidgets();
    void updatetime();



};

#endif // CLOCK_H
